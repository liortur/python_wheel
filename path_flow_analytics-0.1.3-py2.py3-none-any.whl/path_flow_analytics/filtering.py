import pandas as pd
import numpy as np

#filter logs by included node
def by_included_node(node, df_logs_formated):
    filtered_df_logs = None
    
    df_by_conversation_id = df_logs_formated.sort_values(by=["response_timestamp"]).groupby(by="conversation_id")
    ConvDict = {}
    for key, group in df_by_conversation_id:
        ConvDict[key] = group
        
    for i, (k, v) in enumerate(ConvDict.items()):
        dfP1=pd.DataFrame(v, columns=v.columns).sort_values(by=['response_timestamp'])
        if any(dfP1['node_visited'] == node):
            filtered_df_logs = pd.concat([filtered_df_logs,dfP1])
    return filtered_df_logs

## filter conversations starting with initial intent
def by_initial_intent(intent, df_logs_formated):
    filtered_df_logs = None
    
    df_by_conversation_id = df_logs_formated.sort_values(by=["response_timestamp"]).groupby(by="conversation_id")
    ConvDict = {}
    for key, group in df_by_conversation_id:
        ConvDict[key] = group
    
    for i, (k, v) in enumerate(ConvDict.items()):
        dfP1=pd.DataFrame(v, columns=v.columns).sort_values(by=['response_timestamp'])
        if (dfP1['response_intent'].iloc[0] == intent):
            filtered_df_logs = pd.concat([filtered_df_logs,dfP1])
    return filtered_df_logs

## filtering by truncating conversations from selected node onwards

def from_node_onwards(node, df_logs_formated):
    filtered_df_logs = None
    df_by_conversation_id = df_logs_formated.sort_values(by=["response_timestamp"]).groupby(by="conversation_id")
    for conversation_id, conversation_df in df_by_conversation_id:
        i=0
        for index, row in conversation_df.iterrows(): 
            i=i+1       
            node_visited = row["node_visited"]
            if node in node_visited:    
                num_of_elements_to_copy = len(conversation_df)-i+1
                filtered_df_logs = pd.concat([filtered_df_logs,conversation_df.tail(num_of_elements_to_copy)])
                break
    return filtered_df_logs


## filter by dates
def by_date_rangw (df, start_date, end_date):
    mask = (pd.to_datetime(df['Date']) > start_date) & (pd.to_datetime(df['Date']) <= end_date)
    df = df.loc[mask].reset_index()
    return df

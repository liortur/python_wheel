import pandas as pd
import numpy as np
import decimal
import datetime
import re

def to_canonical_WA(df, nodes_dict):
    """
    transform WA log format into pathflow dataframe canonical data model
    returns a canonical dataframe with the following mandatory columns

    'log_id'
    'conversation_id'
    'node_visited'
    'response_timestamp'

    """
    df1 = pd.concat([df.drop(['request', 'response'], axis=1).reset_index(drop=True),
                     df['request'].apply(pd.Series).add_prefix('request_').reset_index(drop=True),
                     pd.DataFrame(df['response']
                                  .tolist()).add_prefix('response_')], axis=1)  # type: pd.DataFrame
    df1['request_input'] = pd.io.json.json_normalize(df['request'])['input.text']

    # Add context and output fields
    df2 = pd.concat([df1.drop(['response_context', 'response_output'], axis=1),
                     df1['response_context'].apply(pd.Series).add_prefix('response_context_'),
                     pd.DataFrame(df1['response_output'].tolist()).add_prefix('response_')],axis=1)  # type: pd.DataFrame
    # Add context_system fields
    df3 = pd.concat([df2.drop(['response_context_system'], axis=1),
                     df2['response_context_system'].apply(pd.Series).add_prefix('response_')],
                    axis=1)  # type: pd.DataFrame
    cols = ['log_id', 'response_timestamp', 'request_input', 'response_text' ,'response_context_conversation_id','response_nodes_visited', 'response_branch_exited', 'response_branch_exited_reason']
    df4 = df3[cols].copy(deep=True)  # type: pd.DataFrame

    df4.rename(columns={'response_nodes_visited': 'nodes_visited',
                        'response_context_conversation_id': 'conversation_id',
                       }, inplace=True)
    df4['node_visited']=df4['nodes_visited'].apply(lambda x:x[-1])
    df4['response_timestamp'] = pd.to_datetime(df4['response_timestamp'])
    df4['Date'] = [datetime.datetime.date(d) for d in df4['response_timestamp']]
    df4['node_visited'] = df4['node_visited'].replace(nodes_dict)
    return df4

def _to_canonical(df, nodes_dict):
    df['node_visited']=df['nodes_visited'].str.strip('[]')
    pattern = re.compile(",")
    df['node_visited']=df['node_visited'].apply(lambda x:pattern.split(x))
    for idx, element in enumerate(df['node_visited']):
        element = list(map(lambda x: str.replace(x, "'", "").lstrip(), element))
        nodes_type = list(map(lambda x: list(nodes_dict[x])[1] if x in nodes_dict else x, element))
        indice_standard = [i for i, y in enumerate(nodes_type) if y == "standard"]
        if len (element)>2 and (element[-2]=='Handoff' or element[-2]=='More Help'):
            df.loc[idx, 'node_visited'] = element[-2] 
        else:
            if len (indice_standard) > 0:          
                df.loc[idx, 'node_visited'] = element[indice_standard[-1]]
            else: 
                df.loc[idx, 'node_visited'] = element[-1]
       
            if df.loc[idx, 'node_visited'] in nodes_dict:
                df.loc[idx,'node_visited']=nodes_dict[df.loc[idx, 'node_visited']][0]
    return df
    



def conv_id_dict (df_logs_formated):
    UniqueConv = df_logs_formated.conversation_id.unique()
    ConvDict = {elem : pd.DataFrame for elem in UniqueConv}
    for key in ConvDict.keys():
        ConvDict[key] = df_logs_formated[:][df_logs_formated.conversation_id == key]
    return ConvDict


def extract_dialog_node_name_WA(workspace_nodes):
    """
    Extract more friendly dialog node names from the Watson Assistant workspace
    return a nodes dictionary object.
    """

    nodes_dict = {}
    nodes_type = {}
    for idx,obj in workspace_nodes.iterrows():
        if (obj['type']=='standard') and not (obj['title'] is np.nan or obj['title'] != obj['title']):
            nodes_dict[obj['dialog_node']]=obj['title']
        else:
            nodes_dict[obj['dialog_node']]=obj['dialog_node']
    return nodes_dict


def _extract_dialog_node_name(dialog_nodes):
    nodes_dict = {}
    nodes_type = {}
    for obj in dialog_nodes:
        if (obj['type']=='standard') and ('title' in obj):
            nodes_dict[obj['dialog_node']] = (obj['title'],obj['type'])
        else:
            nodes_dict[obj['dialog_node']] = (obj['dialog_node'],obj['type'])
    return nodes_dict
import pkgutil

print('loading visualization resources')

flowchart_css = pkgutil.get_data(__package__, 'flowchart.css.html')
flowchart_js = pkgutil.get_data(__package__, 'flowchart2.js')

print(flowchart_css)
print(flowchart_js)

print('successfully loaded vis')

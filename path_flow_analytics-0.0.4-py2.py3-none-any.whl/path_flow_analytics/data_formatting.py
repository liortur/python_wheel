import decimal
import pandas as pd
import datetime
import re

def format_data(df, nodes_dict):
    df.rename(columns={'document_id': 'log_id'}, inplace=True)
    df['node_visited']=df['nodes_visited'].str.strip('[]')
    pattern = re.compile(",")
    df['node_visited']=df['node_visited'].apply(lambda x:pattern.split(x))
    df['node_visited']=df['node_visited'].apply(lambda x:x[-2].replace("'", "").lstrip() if (len (x)>2 and (str(x[-2]).replace("'", "").lstrip()=='Handoff' or str(x[-2]).replace("'", "").lstrip()=='More Help')) else x[-1].replace("'", "").lstrip())

    df.loc[:, 'Date'] = df.response_timestamp.apply(lambda x: pd.datetime.fromtimestamp(x/1000).date())
    df['node_visited'] = df['node_visited'].replace(nodes_dict)
    return df

def conv_id_dict (df_logs_formated):
    UniqueConv = df_logs_formated.conversation_id.unique()
    ConvDict = {elem : pd.DataFrame for elem in UniqueConv}
    for key in ConvDict.keys():
        ConvDict[key] = df_logs_formated[:][df_logs_formated.conversation_id == key]
    return ConvDict

def nodes_dict (nodes_df):
    nodes_dict = {}
    nodes_counter = 0
    for node_name in nodes_df:
        nodes_counter +=1
        nodes_dict[node_name] = nodes_counter
    return nodes_dict




import pandas as pd
import numpy as np

def nodes_dict_ws (dialog_nodes):
    nodes_dict = {}
    nodes_type = {}
    for obj in dialog_nodes:
        if (obj['type']=='standard') and (obj['title'] is not None):
            nodes_dict[obj['dialog_node']]=obj['title']
        else:
            nodes_dict[obj['dialog_node']]=obj['dialog_node']
    return nodes_dict




